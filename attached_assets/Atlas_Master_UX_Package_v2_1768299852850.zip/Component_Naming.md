# Component Naming Convention

BTN/Primary
BTN/Secondary
TXT/H1
TXT/Body
ALERT/Error
CARD/Option

Rule:
- Names must describe function, not appearance
