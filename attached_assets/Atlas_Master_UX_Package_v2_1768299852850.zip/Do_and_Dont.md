# Do & Don't

DO:
- Follow UX Copy exactly
- Ask before changing logic
- Design for real usage

DON'T:
- Rewrite text for aesthetics
- Add steps
- Merge SMB & Enterprise logic
