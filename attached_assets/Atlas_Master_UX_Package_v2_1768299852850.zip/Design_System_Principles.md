# Atlas Design System – Principles

1. Clarity over beauty
2. Safety before automation
3. Speed where allowed (SMB)
4. One decision per screen
5. UX drives UI, not the opposite
