# Typography

Text Styles:
- TXT/H1 (single decision headline)
- TXT/H2
- TXT/Body
- TXT/Helper (trust, reassurance)
- TXT/Meta (logs, timestamps)

Rules:
- No decorative headings
- No long paragraphs
