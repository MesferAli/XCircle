Enterprise UX Copy
(Use exactly as provided – do not rewrite for aesthetics)
