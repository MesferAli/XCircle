Recommended Figma Pages:
00 UX Foundations
01 Enterprise Flow
02 SMB Flow
03 Screens – Low Fidelity
04 UI Design
05 UX Review
