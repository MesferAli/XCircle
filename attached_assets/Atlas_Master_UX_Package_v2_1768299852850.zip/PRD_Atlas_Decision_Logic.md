# Atlas – Decision Logic & Adaptive UX (PRD)
This document defines how Atlas routes users between SMB and Enterprise UX paths
based on systems and behavior. Use as a core product reference.
(Provided by Product Owner)
