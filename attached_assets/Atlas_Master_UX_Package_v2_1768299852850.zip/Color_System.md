# Color System (Purpose-Based)

- Neutral/Base: backgrounds
- Primary: one main CTA only
- Success: calm confirmation
- Warning: attention without fear
- Error: issue without blame

Rule:
- Never more than one Primary CTA per screen
