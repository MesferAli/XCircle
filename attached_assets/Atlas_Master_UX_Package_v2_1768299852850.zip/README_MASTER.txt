
Atlas – Master UX Package
========================
This is the single source of truth for Atlas UX.

Contents:
1. PRD & Decision Logic
2. Enterprise UX (Flow, Copy, Checklist)
3. SMB UX (Flow, Copy, Checklist)
4. Figma Starter File Structure
5. Design System Lite

This package is mandatory for UX/UI designers and product teams.
