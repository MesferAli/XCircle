# SMB vs Enterprise UI Tone

SMB:
- Bigger buttons
- Fewer steps
- Less text
- Faster flow

Enterprise:
- More confirmations
- Preview layers
- Calm visual density
