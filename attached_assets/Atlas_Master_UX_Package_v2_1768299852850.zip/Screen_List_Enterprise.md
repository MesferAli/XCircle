Atlas Enterprise – Screen List
01 Entry
02 Select System
03 Access Type
04 Sandbox
05 Select Use Case
06 Preview
07 Execution
08 Success
09 Error Handling
10 Activate Production
