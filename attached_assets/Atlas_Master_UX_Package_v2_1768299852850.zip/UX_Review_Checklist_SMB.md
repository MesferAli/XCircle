SMB UX Review Checklist
Focus: speed, clarity, momentum
