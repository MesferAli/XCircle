SMB UX Copy
(Short, direct, speed-first copy)
