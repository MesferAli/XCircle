Atlas Design System Lite
========================
This package defines the minimum design system required to ensure
consistent, human-first UX across Atlas (Enterprise & SMB).

Use this system inside Figma before any UI polish.
