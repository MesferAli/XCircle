
Atlas – UX Intent & Constraints
===============================

This document explains the UX intent and non-negotiable constraints for Atlas.
It is written for professional designers to understand *what must be achieved*
and *what must not be broken*, without prescribing visual solutions.

[Content intentionally authoritative and design-respectful]
