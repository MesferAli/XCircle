# Buttons & Core Components

Buttons:
- BTN/Primary
- BTN/Secondary
- BTN/Text

Alerts:
- ALERT/Info
- ALERT/Success
- ALERT/Warning
- ALERT/Error

Rules:
- Primary = one per screen
- No competing CTAs
