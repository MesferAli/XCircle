# Layout Rules

- Single column in 90% of screens
- Two columns only for comparison
- White space is intentional
- Fewer elements = more trust
