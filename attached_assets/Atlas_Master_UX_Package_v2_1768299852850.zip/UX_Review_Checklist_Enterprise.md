Enterprise UX Review Checklist
Focus: safety, control, reversibility
